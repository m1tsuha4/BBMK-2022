<div class="footer py-5 px-3 mt-5">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-md-4">
                <div class="d-flex name-footer">
                    <img src="<?= base_url() ?>assets22/logo/logobbmk22.png" alt="" width="548.88px" height="188px" class="ms-3 img-footer">
                </div>
            </div>
            <div class="col-md-4 kolaborasi">
                <h5>Berkolaborasi Bersama</h5>
                <p class="logoFooter">
                    <img src="<?= base_url(); ?>assets22/NEO PNG 2.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/PHP PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/UKS PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/UKO PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/SINEMA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/PIKMAG PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/PIKA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/UKMP PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/PANDEKAR PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/MENWA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/MAPALA PNG 2.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/KSR PMI PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/KOSBEMA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/KOPMA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/HIPMI PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/GENTA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/FKI RABBANI PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/PRAMUKA PNG 1.png" alt="" width="10%">
                    <img src="<?= base_url(); ?>assets22/AIESEC PNG 1.png" alt="" width="10%">
                </p>
            </div>
        </div>
             
    
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://anijs.github.io/lib/anijs/anijs-min.js"></script>

<!-- Include to use $addClass, $toggleClass or $removeClass -->
<script src="https://anijs.github.io/lib/anijs/helpers/dom/anijs-helper-dom-min.js"></script>
<!-- The scrollreveal helper -->
<script src="https://anijs.github.io/lib/anijs/helpers/scrollreveal/anijs-helper-scrollreveal-min.js"></script>
</body>

</html>