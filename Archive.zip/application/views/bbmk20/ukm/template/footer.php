</div>
</div>
<style type="text/css">
	#copyright {
		position: fixed;
		bottom: 0;
		right: 0;
		z-index: 9999;
	}
</style>

<div id="copyright">
	Copyright &copy; 2021 By <img src="<?= base_url(); ?>assets/img/logo-neo.png" height="30px">
</div>